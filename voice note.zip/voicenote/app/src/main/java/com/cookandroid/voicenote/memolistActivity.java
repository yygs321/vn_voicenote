package com.cookandroid.voicenote;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class memolistActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memolist);

        
        //작성하기 버튼
        Button button= findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(memolistActivity.this, MainActivity.class);
                startActivityForResult(intent, 0);

                finish();
            }
        });

        //지금은 작성화면으로 돌아가게 해두었는데 나중엔 새로고침 버튼으로
        Button button3= findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), memolistActivity.class);
                intent.putExtra("back","main");

                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==0){
            //MainActivity에서 입력받은 메모데이터값 받아오기
            String strMain= data.getStringExtra("main");
            String strSub= data.getStringExtra("sub");

            /*
            //Gradle Scripts에(앱단위 그래들)에 recyclerView 추가
            Memo memo= new Memo(strMain, strSub,0);
            recyclerAdapter.addItem(memo);
            recyclerAdapter.notifyDataSetChanged();
             */
        }
    }
    /*메뉴바 없으니까 삭제..?
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.home:
                Intent homeintent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(homeintent);
                break;
            case R.id.memo:
                Intent memointent = new Intent(getApplicationContext(), memolistActivity.class);
                startActivity(memointent);
        }
        return super.onOptionsItemSelected(item);
    }

     */
}
