package com.cookandroid.voicenote;

import androidx.appcompat.app.AppCompatActivity;

import android.app.UiAutomation;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    
        //주석테스트
        
        //로고 버튼: 리스트로 이동
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), memolistActivity.class);
                startActivityForResult(intent, 101);
            }
        });

        editText = findViewById(R.id.editText);
        Button button= findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //새로운 메모 작성
                String str=editText.getText().toString();
                //메모에 하나라도 썼을 경우에만 실행
                if(str.length()>0){
                    //날짜
                    Date date= new Date();
                    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

                    String substr =sdf.format(date);

                    //입력받은 메모 리스트로 보내기
                    Intent intent = new Intent();
                    intent.putExtra("main", str);
                    intent.putExtra("sub",substr);
                    setResult(RESULT_OK, intent);

                    Toast.makeText(MainActivity.this, str+","+substr, Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    /* 메뉴바
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.home:
                Intent homeintent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(homeintent);
                break;
            case R.id.memo:
                Intent memointent = new Intent(getApplicationContext(), memolistActivity.class);
                startActivity(memointent);
        }
        return super.onOptionsItemSelected(item);
    }

     */

}
